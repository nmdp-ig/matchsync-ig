# HLA HGNC GeneID CodeSystem - v0.1.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **HLA HGNC GeneID CodeSystem**

## CodeSystem: HLA HGNC GeneID CodeSystem (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://www.genenames.org/geneId | *Version*:0.1.4 |
| Active as of 2026-04-24 | *Computable Name*:HLAGeneIdCS |
| **Copyright/Legal**: National Human Genome Research Institute (NHGRI) | |

 
CodeSystem of HLA gene group subset of HGNC GeneId Codesystem 

 This Code system is referenced in the content logical definition of the following value sets: 

* [HLAGeneIdVS](ValueSet-hla-geneid-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "hla-genename-codesystem",
  "url" : "http://www.genenames.org/geneId",
  "version" : "0.1.4",
  "name" : "HLAGeneIdCS",
  "title" : "HLA HGNC GeneID CodeSystem",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-04-24T15:44:03+00:00",
  "publisher" : "NMDP",
  "contact" : [{
    "name" : "NMDP",
    "telecom" : [{
      "system" : "url",
      "value" : "http://bethematch.org"
    }]
  }],
  "description" : "CodeSystem of HLA gene group subset of HGNC GeneId Codesystem",
  "copyright" : "National Human Genome Research Institute (NHGRI)",
  "caseSensitive" : true,
  "content" : "fragment",
  "concept" : [{
    "code" : "HGNC:4931",
    "display" : "HLA-A",
    "definition" : "major histocompatibility complex, class I, A"
  },
  {
    "code" : "HGNC:4932",
    "display" : "HLA-B",
    "definition" : "major histocompatibility complex, class I, B"
  },
  {
    "code" : "HGNC:4933",
    "display" : "HLA-C",
    "definition" : "major histocompatibility complex, class I, C"
  },
  {
    "code" : "HGNC:4934",
    "display" : "HLA-DMA",
    "definition" : "major histocompatibility complex, class II, DM alpha"
  },
  {
    "code" : "HGNC:4935",
    "display" : "HLA-DMB",
    "definition" : "major histocompatibility complex, class II, DM beta"
  },
  {
    "code" : "HGNC:4936",
    "display" : "HLA-DOA",
    "definition" : "major histocompatibility complex, class II, DO alpha"
  },
  {
    "code" : "HGNC:4937",
    "display" : "HLA-DOB",
    "definition" : "major histocompatibility complex, class II, DO beta"
  },
  {
    "code" : "HGNC:4938",
    "display" : "HLA-DPA1",
    "definition" : "major histocompatibility complex, class II, DP alpha 1"
  },
  {
    "code" : "HGNC:4939",
    "display" : "HLA-DPA2",
    "definition" : "major histocompatibility complex, class II, DP alpha 2 (pseudogene)"
  },
  {
    "code" : "HGNC:19393",
    "display" : "HLA-DPA3",
    "definition" : "major histocompatibility complex, class II, DP alpha 3 (pseudogene)"
  },
  {
    "code" : "HGNC:4940",
    "display" : "HLA-DPB1",
    "definition" : "major histocompatibility complex, class II, DP beta 1"
  },
  {
    "code" : "HGNC:4941",
    "display" : "HLA-DPB2",
    "definition" : "major histocompatibility complex, class II, DP beta 2 (pseudogene)"
  },
  {
    "code" : "HGNC:4942",
    "display" : "HLA-DQA1",
    "definition" : "major histocompatibility complex, class II, DQ alpha 1"
  },
  {
    "code" : "HGNC:4943",
    "display" : "HLA-DQA2",
    "definition" : "major histocompatibility complex, class II, DQ alpha 2"
  },
  {
    "code" : "HGNC:4944",
    "display" : "HLA-DQB1",
    "definition" : "major histocompatibility complex, class II, DQ beta 1"
  },
  {
    "code" : "HGNC:4945",
    "display" : "HLA-DQB2",
    "definition" : "major histocompatibility complex, class II, DQ beta 2"
  },
  {
    "code" : "HGNC:4946",
    "display" : "HLA-DQB3",
    "definition" : "major histocompatibility complex, class II, DQ beta 3"
  },
  {
    "code" : "HGNC:4947",
    "display" : "HLA-DRA",
    "definition" : "major histocompatibility complex, class II, DR alpha"
  },
  {
    "code" : "HGNC:4948",
    "display" : "HLA-DRB1",
    "definition" : "major histocompatibility complex, class II, DR beta 1"
  },
  {
    "code" : "HGNC:4950",
    "display" : "HLA-DRB2",
    "definition" : "major histocompatibility complex, class II, DR beta 2 (pseudogene)"
  },
  {
    "code" : "HGNC:4951",
    "display" : "HLA-DRB3",
    "definition" : "major histocompatibility complex, class II, DR beta 3"
  },
  {
    "code" : "HGNC:4952",
    "display" : "HLA-DRB4",
    "definition" : "major histocompatibility complex, class II, DR beta 4"
  },
  {
    "code" : "HGNC:4953",
    "display" : "HLA-DRB5",
    "definition" : "major histocompatibility complex, class II, DR beta 5"
  },
  {
    "code" : "HGNC:4954",
    "display" : "HLA-DRB6",
    "definition" : "major histocompatibility complex, class II, DR beta 6 (pseudogene)"
  },
  {
    "code" : "HGNC:4955",
    "display" : "HLA-DRB7",
    "definition" : "major histocompatibility complex, class II, DR beta 7 (pseudogene)"
  },
  {
    "code" : "HGNC:4956",
    "display" : "HLA-DRB8",
    "definition" : "major histocompatibility complex, class II, DR beta 8 (pseudogene)"
  },
  {
    "code" : "HGNC:4957",
    "display" : "HLA-DRB9",
    "definition" : "major histocompatibility complex, class II, DR beta 9 (pseudogene)"
  },
  {
    "code" : "HGNC:4962",
    "display" : "HLA-E",
    "definition" : "major histocompatibility complex, class I, E"
  },
  {
    "code" : "HGNC:4963",
    "display" : "HLA-F",
    "definition" : "major histocompatibility complex, class I, F"
  },
  {
    "code" : "HGNC:4964",
    "display" : "HLA-G",
    "definition" : "major histocompatibility complex, class I, G"
  },
  {
    "code" : "HGNC:4965",
    "display" : "HLA-H",
    "definition" : "major histocompatibility complex, class I, H (pseudogene)"
  },
  {
    "code" : "HGNC:4967",
    "display" : "HLA-J",
    "definition" : "major histocompatibility complex, class I, J (pseudogene)"
  },
  {
    "code" : "HGNC:4969",
    "display" : "HLA-K",
    "definition" : "major histocompatibility complex, class I, K (pseudogene)"
  },
  {
    "code" : "HGNC:4970",
    "display" : "HLA-L",
    "definition" : "major histocompatibility complex, class I, L (pseudogene)"
  },
  {
    "code" : "HGNC:19406",
    "display" : "HLA-N",
    "definition" : "major histocompatibility complex, class I, N (pseudogene)"
  },
  {
    "code" : "HGNC:21196",
    "display" : "HLA-P",
    "definition" : "major histocompatibility complex, class I, P (pseudogene)"
  },
  {
    "code" : "HGNC:19395",
    "display" : "HLA-S",
    "definition" : "major histocompatibility complex, class I, S (pseudogene)"
  },
  {
    "code" : "HGNC:23478",
    "display" : "HLA-T",
    "definition" : "major histocompatibility complex, class I, T (pseudogene)"
  },
  {
    "code" : "HGNC:23477",
    "display" : "HLA-U",
    "definition" : "major histocompatibility complex, class I, U (pseudogene)"
  },
  {
    "code" : "HGNC:23482",
    "display" : "HLA-V",
    "definition" : "major histocompatibility complex, class I, V (pseudogene)"
  },
  {
    "code" : "HGNC:23425",
    "display" : "HLA-W",
    "definition" : "major histocompatibility complex, class I, W (pseudogene)"
  },
  {
    "code" : "HGNC:19385",
    "display" : "HLA-X",
    "definition" : "major histocompatibility complex, class I, X (pseudogene)"
  },
  {
    "code" : "HGNC:33913",
    "display" : "HLA-Y",
    "definition" : "major histocompatibility complex, class I, Y (pseudogene)"
  },
  {
    "code" : "HGNC:19394",
    "display" : "HLA-Z",
    "definition" : "major histocompatibility complex, class I, Z (pseudogene)"
  }]
}

```
