# MatchSync Bundle Example - Practioners - v0.1.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MatchSync Bundle Example - Practioners**

## Example Bundle: MatchSync Bundle Example - Practioners



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BundleExample-Practitioner",
  "meta" : {
    "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-bundle"],
    "security" : [{
      "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
      "code" : "tc_123"
    }]
  },
  "type" : "collection",
  "timestamp" : "2020-11-24T23:50:50-05:00",
  "entry" : [{
    "fullUrl" : "urn:uuid:3f7d88b1-3e39-4f52-bb9c-5d680b7166b3",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "3f7d88b1-3e39-4f52-bb9c-5d680b7166b3",
      "meta" : {
        "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"],
        "security" : [{
          "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
          "code" : "tc_123"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_3f7d88b1-3e39-4f52-bb9c-5d680b7166b3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 3f7d88b1-3e39-4f52-bb9c-5d680b7166b3</b></p><a name=\"3f7d88b1-3e39-4f52-bb9c-5d680b7166b3\"> </a><a name=\"hc3f7d88b1-3e39-4f52-bb9c-5d680b7166b3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mspatient.html\">MSPatient</a></p><p style=\"margin-bottom: 0px\">Security Label: tc_123 (Details: transplant-center code tc_123)</p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Jane Everyperson  Female, DoB: 1974-12-25 ( http://example.org/mrn#123)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\"><ul><li>ph: 1-612-555-1234</li><li>123 Main St Minneapolis MN 55401 USA </li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Patient Links\">Links:</td><td colspan=\"3\"><ul><li>General Practitioner: <a href=\"Bundle-BundleExample-Practitioner.html#urn-uuid-f1942bac-b8b3-45a1-b1d0-6928326d03ce\">Referring Physician</a></li><li>General Practitioner: <a href=\"Bundle-BundleExample-Practitioner.html#urn-uuid-8fd0ef20-d146-4fff-b2a8-1d607adf9802\">TC Physician</a></li><li>General Practitioner: <a href=\"Bundle-BundleExample-Practitioner.html#urn-uuid-ad78058a-c0fe-4ea0-bc86-d2f3770a1944\">Search Coordinator</a></li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Concepts classifying the person into a named category of humans sharing common history, traits, geographical origin or nationality.  The ethnicity codes used to represent these concepts are based upon the [CDC ethnicity and Ethnicity Code Set Version 1.0](http://www.cdc.gov/phin/resources/vocabulary/index.html) which includes over 900 concepts for representing race and ethnicity of which 43 reference ethnicity.  The ethnicity concepts are grouped by and pre-mapped to the 2 OMB ethnicity categories: - Hispanic or Latino - Not Hispanic or Latino.\">US Core Ethnicity Extension:</td><td colspan=\"3\"><ul><li>ombCategory: <a href=\"http://hl7.org/fhir/us/core/STU4/CodeSystem-cdcrec.html#cdcrec-2186-5\">Race &amp; Ethnicity - CDC: 2186-5</a> (Not Hispanic or Latino)</li><li>text: Not Hispanic or Latino</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Concepts classifying the person into a named category of humans sharing common history, traits, geographical origin or nationality.  The race codes used to represent these concepts are based upon the [CDC Race and Ethnicity Code Set Version 1.0](http://www.cdc.gov/phin/resources/vocabulary/index.html) which includes over 900 concepts for representing race and ethnicity of which 921 reference race.  The race concepts are grouped by and pre-mapped to the 5 OMB race categories:\n\n - American Indian or Alaska Native\n - Asian\n - Black or African American\n - Native Hawaiian or Other Pacific Islander\n - White.\">US Core Race Extension:</td><td colspan=\"3\"><ul><li>ombCategory: <a href=\"http://hl7.org/fhir/us/core/STU4/CodeSystem-cdcrec.html#cdcrec-2186-5\">Race &amp; Ethnicity - CDC: 2186-5</a> (White)</li><li>text: White</li></ul></td></tr></table></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "ombCategory",
          "valueCoding" : {
            "system" : "urn:oid:2.16.840.1.113883.6.238",
            "code" : "2186-5",
            "display" : "White"
          }
        },
        {
          "url" : "text",
          "valueString" : "White"
        }],
        "url" : "http://hl7.org/fhir/us/core/StructureDefinition/us-core-race"
      },
      {
        "extension" : [{
          "url" : "ombCategory",
          "valueCoding" : {
            "system" : "urn:oid:2.16.840.1.113883.6.238",
            "code" : "2186-5",
            "display" : "Not Hispanic or Latino"
          }
        },
        {
          "url" : "text",
          "valueString" : "Not Hispanic or Latino"
        }],
        "url" : "http://hl7.org/fhir/us/core/StructureDefinition/us-core-ethnicity"
      }],
      "identifier" : [{
        "system" : "http://example.org/mrn",
        "value" : "123"
      }],
      "name" : [{
        "family" : "Everyperson",
        "given" : ["Jane"]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "1-612-555-1234"
      }],
      "gender" : "female",
      "birthDate" : "1974-12-25",
      "address" : [{
        "line" : ["123 Main St"],
        "city" : "Minneapolis",
        "state" : "MN",
        "postalCode" : "55401",
        "country" : "USA"
      }],
      "generalPractitioner" : [{
        "reference" : "urn:uuid:f1942bac-b8b3-45a1-b1d0-6928326d03ce",
        "display" : "Referring Physician"
      },
      {
        "reference" : "urn:uuid:8fd0ef20-d146-4fff-b2a8-1d607adf9802",
        "display" : "TC Physician"
      },
      {
        "reference" : "urn:uuid:ad78058a-c0fe-4ea0-bc86-d2f3770a1944",
        "display" : "Search Coordinator"
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:ad78058a-c0fe-4ea0-bc86-d2f3770a1944",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "ad78058a-c0fe-4ea0-bc86-d2f3770a1944",
      "meta" : {
        "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"],
        "security" : [{
          "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
          "code" : "tc_123"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_ad78058a-c0fe-4ea0-bc86-d2f3770a1944\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole ad78058a-c0fe-4ea0-bc86-d2f3770a1944</b></p><a name=\"ad78058a-c0fe-4ea0-bc86-d2f3770a1944\"> </a><a name=\"hcad78058a-c0fe-4ea0-bc86-d2f3770a1944\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-nmdp-practitioner-role.html\">NMDPPractitionerRole</a></p><p style=\"margin-bottom: 0px\">Security Label: tc_123 (Details: transplant-center code tc_123)</p></div><p><b>practitioner</b>: <a href=\"Bundle-BundleExample-Practitioner.html#urn-uuid-fe6acf5d-ed53-4758-8d38-10d915c984af\">Bart Simpson</a></p><p><b>code</b>: <span title=\"Codes:{http://terminology.nmdp.org/codesystem/practitionerrole tccoordinator}\">Transplant Center Coordinator</span></p></div>"
      },
      "practitioner" : {
        "reference" : "urn:uuid:fe6acf5d-ed53-4758-8d38-10d915c984af",
        "display" : "Bart Simpson"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://terminology.nmdp.org/codesystem/practitionerrole",
          "code" : "tccoordinator",
          "display" : "Transplant Center Coordinator"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:8fd0ef20-d146-4fff-b2a8-1d607adf9802",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "8fd0ef20-d146-4fff-b2a8-1d607adf9802",
      "meta" : {
        "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"],
        "security" : [{
          "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
          "code" : "tc_123"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_8fd0ef20-d146-4fff-b2a8-1d607adf9802\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole 8fd0ef20-d146-4fff-b2a8-1d607adf9802</b></p><a name=\"8fd0ef20-d146-4fff-b2a8-1d607adf9802\"> </a><a name=\"hc8fd0ef20-d146-4fff-b2a8-1d607adf9802\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-nmdp-practitioner-role.html\">NMDPPractitionerRole</a></p><p style=\"margin-bottom: 0px\">Security Label: tc_123 (Details: transplant-center code tc_123)</p></div><p><b>practitioner</b>: <a href=\"Bundle-BundleExample-Practitioner.html#urn-uuid-26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa\">Lisa Simpson</a></p><p><b>code</b>: <span title=\"Codes:{http://terminology.nmdp.org/codesystem/practitionerrole tcphysician}\">Transplant Center Physician</span></p></div>"
      },
      "practitioner" : {
        "reference" : "urn:uuid:26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa",
        "display" : "Lisa Simpson"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://terminology.nmdp.org/codesystem/practitionerrole",
          "code" : "tcphysician",
          "display" : "Transplant Center Physician"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:f1942bac-b8b3-45a1-b1d0-6928326d03ce",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "f1942bac-b8b3-45a1-b1d0-6928326d03ce",
      "meta" : {
        "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"],
        "security" : [{
          "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
          "code" : "tc_123"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"PractitionerRole_f1942bac-b8b3-45a1-b1d0-6928326d03ce\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole f1942bac-b8b3-45a1-b1d0-6928326d03ce</b></p><a name=\"f1942bac-b8b3-45a1-b1d0-6928326d03ce\"> </a><a name=\"hcf1942bac-b8b3-45a1-b1d0-6928326d03ce\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-nmdp-practitioner-role.html\">NMDPPractitionerRole</a></p><p style=\"margin-bottom: 0px\">Security Label: tc_123 (Details: transplant-center code tc_123)</p></div><p><b>practitioner</b>: <a href=\"Bundle-BundleExample-Practitioner.html#urn-uuid-26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa\">Lisa Simpson</a></p><p><b>code</b>: <span title=\"Codes:{http://terminology.nmdp.org/codesystem/practitionerrole referringphysician}\">Referring Physician</span></p></div>"
      },
      "practitioner" : {
        "reference" : "urn:uuid:26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa",
        "display" : "Lisa Simpson"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://terminology.nmdp.org/codesystem/practitionerrole",
          "code" : "referringphysician",
          "display" : "Referring Physician"
        }]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa",
      "meta" : {
        "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner"],
        "security" : [{
          "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
          "code" : "tc_123"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner 26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa</b></p><a name=\"26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa\"> </a><a name=\"hc26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-nmdp-practitioner.html\">NMDPPractitioner</a></p><p style=\"margin-bottom: 0px\">Security Label: tc_123 (Details: transplant-center code tc_123)</p></div><p><b>name</b>: Lisa Simpson </p></div>"
      },
      "name" : [{
        "family" : "Simpson",
        "given" : ["Lisa"]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:fe6acf5d-ed53-4758-8d38-10d915c984af",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "fe6acf5d-ed53-4758-8d38-10d915c984af",
      "meta" : {
        "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner"],
        "security" : [{
          "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
          "code" : "tc_123"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_fe6acf5d-ed53-4758-8d38-10d915c984af\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner fe6acf5d-ed53-4758-8d38-10d915c984af</b></p><a name=\"fe6acf5d-ed53-4758-8d38-10d915c984af\"> </a><a name=\"hcfe6acf5d-ed53-4758-8d38-10d915c984af\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-nmdp-practitioner.html\">NMDPPractitioner</a></p><p style=\"margin-bottom: 0px\">Security Label: tc_123 (Details: transplant-center code tc_123)</p></div><p><b>name</b>: Bart Simpson </p></div>"
      },
      "name" : [{
        "family" : "Simpson",
        "given" : ["Bart"]
      }]
    }
  },
  {
    "fullUrl" : "urn:uuid:a9e56f2a-0827-4efd-a773-ed48c6e2752c",
    "resource" : {
      "resourceType" : "Condition",
      "id" : "a9e56f2a-0827-4efd-a773-ed48c6e2752c",
      "meta" : {
        "profile" : ["http://fhir.nmdp.org/ig/matchsync/StructureDefinition/msdiagnosis"],
        "security" : [{
          "system" : "http://terminology.nmdp.org/codesystem/transplant-center",
          "code" : "tc_123"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_a9e56f2a-0827-4efd-a773-ed48c6e2752c\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition a9e56f2a-0827-4efd-a773-ed48c6e2752c</b></p><a name=\"a9e56f2a-0827-4efd-a773-ed48c6e2752c\"> </a><a name=\"hca9e56f2a-0827-4efd-a773-ed48c6e2752c\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-msdiagnosis.html\">MSPrimaryDiagnosis</a></p><p style=\"margin-bottom: 0px\">Security Label: tc_123 (Details: transplant-center code tc_123)</p></div><p><b>Number of Remissions of Primary Diagnosis</b>: 0</p><p><b>code</b>: <span title=\"Codes:{http://terminology.nmdp.org/codesystem/disease AML}\">ACUTE MYELOGENOUS LEUKEMIA</span></p><p><b>subject</b>: <a href=\"Bundle-BundleExample-Practitioner.html#urn-uuid-3f7d88b1-3e39-4f52-bb9c-5d680b7166b3\">Jane Everyperson  Female, DoB: 1974-12-25 ( http://example.org/mrn#123)</a></p><p><b>recordedDate</b>: 2021-11-01</p><h3>Stages</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Summary</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.nmdp.org/codesystem/diseasestage AP}\">Accelerated Phase</span></td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/number-of-remissions",
        "valueInteger" : 0
      }],
      "code" : {
        "coding" : [{
          "system" : "http://terminology.nmdp.org/codesystem/disease",
          "code" : "AML",
          "display" : "ACUTE MYELOGENOUS LEUKEMIA"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:3f7d88b1-3e39-4f52-bb9c-5d680b7166b3"
      },
      "recordedDate" : "2021-11-01",
      "stage" : [{
        "summary" : {
          "coding" : [{
            "system" : "http://terminology.nmdp.org/codesystem/diseasestage",
            "code" : "AP",
            "display" : "Accelerated Phase"
          }]
        }
      }]
    }
  }]
}

```
