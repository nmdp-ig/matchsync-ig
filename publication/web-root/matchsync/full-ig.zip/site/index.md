# Home - v0.1.4

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.nmdp.org/ig/matchsync/ImplementationGuide/nmdp.fhir.matchsync | *Version*:0.1.4 |
| Draft as of 2026-11-23 | *Computable Name*:MatchSyncIG |

### MatchSyncIG

This is a prelimary draft of the MatchSync FHIR Implementation Guide (IG). This IG describes how a bundle of FHIR resources may be used to to POST to an NMDP endpoint for the registering a Patient with MatchSync.

As of now, it mostly contains Structure Definitions, Code Systems, ValueSets and examples. It does not yet contain info on how to submit this data to an endpoint. It also needs more narrative to explain how to use the profiles and other artifacts.

This IG describes FHIR profiles and examples for

* Patient needing the transplant
* Condition to describe the patient's diagnosis, disease stage, and number of remissions
* Specimen to identify the Id of the specimen used for HLA genotyping
* Observations for 
* weight
* height
* ABO blood group type
* Rh status
* transplant timeline
* preferred product
* HLA genotypes
 
* Organization for Transplant Center
* Practioner to identify the Transplant Center Coordinator
* Extensions to use NMDP race and ethnicity with Patient resource
* FHIR bundles to contain it all

Work To Do:

* what identifers should be specified?
* more work on code systems and value sets
* verify what is required and what is optional

Click on the Artifacts tab above to see the contents of this IG.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "nmdp.fhir.matchsync",
  "url" : "http://fhir.nmdp.org/ig/matchsync/ImplementationGuide/nmdp.fhir.matchsync",
  "version" : "0.1.4",
  "name" : "MatchSyncIG",
  "status" : "draft",
  "date" : "2026-11-23T18:39:33+00:00",
  "publisher" : "NMDP",
  "contact" : [{
    "name" : "NMDP",
    "telecom" : [{
      "system" : "url",
      "value" : "http://bethematch.org"
    }]
  }],
  "packageId" : "nmdp.fhir.matchsync",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.5.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.4.0"
  },
  {
    "id" : "hl7_fhir_us_core",
    "uri" : "http://hl7.org/fhir/us/core/ImplementationGuide/hl7.fhir.us.core",
    "packageId" : "hl7.fhir.us.core",
    "version" : "4.0.0"
  },
  {
    "id" : "mcode",
    "uri" : "http://hl7.org/fhir/us/mcode/ImplementationGuide/hl7.fhir.us.mcode",
    "packageId" : "hl7.fhir.us.mcode",
    "version" : "2.0.0"
  },
  {
    "id" : "hl7_fhir_uv_genomics_reporting",
    "uri" : "http://hl7.org/fhir/uv/genomics-reporting/ImplementationGuide/hl7.fhir.uv.genomics-reporting",
    "packageId" : "hl7.fhir.uv.genomics-reporting",
    "version" : "2.0.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2022+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/disease"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/diseasestage"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/abogroup"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/aborhgroup"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/rhstatus"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/cmv"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/race"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/ethnicity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/language"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/preferredproduct"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/transplanttimeline"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/practitionerrole"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/form117compliance"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://terminology.nmdp.org/codesystem/genderidentity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://www.glstring.org"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://www.genenames.org/geneId"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://loinc.org/vs/LL2419-1"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://loinc.org/vs/LL360-9"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://loinc.org/vs/LL2972-9"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://loinc.org/vs/LL3639-3"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://fhir.nmdp.org/ig/matchsync/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa.html"
      }],
      "reference" : {
        "reference" : "Practitioner/26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa"
      },
      "name" : "26b2e265-9a7a-4e5e-b99d-bb301e8a3bfa",
      "description" : "Example of a physician practitioner.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-3f7d88b1-3e39-4f52-bb9c-5d680b7166b3.html"
      }],
      "reference" : {
        "reference" : "Patient/3f7d88b1-3e39-4f52-bb9c-5d680b7166b3"
      },
      "name" : "3f7d88b1-3e39-4f52-bb9c-5d680b7166b3",
      "description" : "Example of a patient needing a donor using us-core-race and us-core-ethnicity codes.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-8fd0ef20-d146-4fff-b2a8-1d607adf9802.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/8fd0ef20-d146-4fff-b2a8-1d607adf9802"
      },
      "name" : "8fd0ef20-d146-4fff-b2a8-1d607adf9802",
      "description" : "Example of Transplant Center Physician Role",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-a9e56f2a-0827-4efd-a773-ed48c6e2752c.html"
      }],
      "reference" : {
        "reference" : "Condition/a9e56f2a-0827-4efd-a773-ed48c6e2752c"
      },
      "name" : "a9e56f2a-0827-4efd-a773-ed48c6e2752c",
      "description" : "Example of a Diagnois: AML",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/msdiagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-ad78058a-c0fe-4ea0-bc86-d2f3770a1944.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/ad78058a-c0fe-4ea0-bc86-d2f3770a1944"
      },
      "name" : "ad78058a-c0fe-4ea0-bc86-d2f3770a1944",
      "description" : "Example of Transplant Center Search Coordinotor Role",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-abo-group-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-abo-group-cs"
      },
      "name" : "CodeSystem - Blood Group (ABO) - NMDP",
      "description" : "Code System for NMDP ABO blood groups",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-abo-rh-group-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-abo-rh-group-cs"
      },
      "name" : "CodeSystem - Blood Group (ABO+RH) - NMDP",
      "description" : "Code System for NMDP ABO RH blood groups",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-rh-status-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-rh-status-cs"
      },
      "name" : "CodeSystem - Blood Group (Rh) - NMDP",
      "description" : "Code System for NMDP Rh Status",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-cmv-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-cmv-cs"
      },
      "name" : "CodeSystem - CMV Group - NMDP",
      "description" : "Code System for NMDP CMV",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-disease-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-disease-cs"
      },
      "name" : "CodeSystem - Disease - NMDP",
      "description" : "Code System for NMDP diseases",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-diseasestage-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-diseasestage-cs"
      },
      "name" : "CodeSystem - Disease Stage - NMDP",
      "description" : "Code System for NMDP disease stages",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-form117-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-form117-cs"
      },
      "name" : "CodeSystem - Form117 Compliance- NMDP",
      "description" : "NMDP Form 117 for MatchSync patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-language-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-language-cs"
      },
      "name" : "CodeSystem - Language - NMDP",
      "description" : "Code System for NMDP languages",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-cdc-race-ethnicity-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/cdc-race-ethnicity-cs"
      },
      "name" : "CodeSystem - Patient Ethnicity - CDC",
      "description" : "Code System for CDC race and ethnicity",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-ethnicity-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-ethnicity-cs"
      },
      "name" : "CodeSystem - Patient Ethnicity - NMDP",
      "description" : "Code System for NMDP ethnicity",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-GenderIdentity-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-GenderIdentity-cs"
      },
      "name" : "CodeSystem - Patient Gender Identity - NMDP",
      "description" : "Code System for NMDP diseases",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-race-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-race-cs"
      },
      "name" : "CodeSystem - Patient Race - NMDP",
      "description" : "Code System for NMDP diseases",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-practitioner-role-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-practitioner-role-cs"
      },
      "name" : "CodeSystem - PractitionerRole - NMDP",
      "description" : "NMDP Practitioner Roles",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-preferred-product-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-preferred-product-cs"
      },
      "name" : "CodeSystem - Preferred Product - NMDP",
      "description" : "NMDP Preferred Product for MatchSync patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-nmdp-transplant-timeline-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/nmdp-transplant-timeline-cs"
      },
      "name" : "CodeSystem - Transplant Timeline - NMDP",
      "description" : "Code System for NMDP transplant timeline",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-ABOGroup.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-ABOGroup"
      },
      "name" : "Example-MS-ABOGroup",
      "description" : "Example of patient ABO",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-abogroup-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-ABORH.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-ABORH"
      },
      "name" : "Example-MS-ABORH",
      "description" : "Example of patient ABO and RH",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-aborhgroup-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-CMV.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-CMV"
      },
      "name" : "Example-MS-CMV",
      "description" : "Example of Cytomeglovirus found in patient",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-cmvgroup-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-Form117Compliance.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-Form117Compliance"
      },
      "name" : "Example-MS-Form117Compliance",
      "description" : "Example of Form 117 Compliance for patient",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-form117-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-PatientHeight.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-PatientHeight"
      },
      "name" : "Example-MS-PatientHeight",
      "description" : "Example of patient height",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-height-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-PatientWeight.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-PatientWeight"
      },
      "name" : "Example-MS-PatientWeight",
      "description" : "Example of patient weight",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-weight-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-PreferredProduct.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-PreferredProduct"
      },
      "name" : "Example-MS-PreferredProduct",
      "description" : "Example of preferred product",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-preferred-product-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-RhStatus.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-RhStatus"
      },
      "name" : "Example-MS-RhStatus",
      "description" : "Example of patient Rh status",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-rhstatus-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-Example-MS-TransplantTimeline.html"
      }],
      "reference" : {
        "reference" : "Observation/Example-MS-TransplantTimeline"
      },
      "name" : "Example-MS-TransplantTimeline",
      "description" : "Example of transplant timeline",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-transplant-timeline-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-f1942bac-b8b3-45a1-b1d0-6928326d03ce.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/f1942bac-b8b3-45a1-b1d0-6928326d03ce"
      },
      "name" : "f1942bac-b8b3-45a1-b1d0-6928326d03ce",
      "description" : "Example of Referring Physician Role",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-fe6acf5d-ed53-4758-8d38-10d915c984af.html"
      }],
      "reference" : {
        "reference" : "Practitioner/fe6acf5d-ed53-4758-8d38-10d915c984af"
      },
      "name" : "fe6acf5d-ed53-4758-8d38-10d915c984af",
      "description" : "Example of a search coordinator practitioner.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-glstring-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/glstring-codesystem"
      },
      "name" : "Genotype List String Code CodeSystem",
      "description" : "Genotype List String Codesystem used for HLA reporting",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-hla-geneid-valueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/hla-geneid-valueset"
      },
      "name" : "HLA Gene Name Value Set",
      "description" : "HLA HGNC GeneIds Valueset",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-genotype.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-genotype"
      },
      "name" : "HLA Genotype Observation",
      "description" : "HLA Genotype profile of genotype observation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-hla-genename-codesystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/hla-genename-codesystem"
      },
      "name" : "HLA HGNC GeneID CodeSystem",
      "description" : "CodeSystem of HLA gene group subset of HGNC GeneId Codesystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-A-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-A-Example"
      },
      "name" : "HLA-A-Example",
      "description" : "Example of HLA-A",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-a"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-B-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-B-Example"
      },
      "name" : "HLA-B-Example",
      "description" : "Example of HLA-B",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-b"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-C-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-C-Example"
      },
      "name" : "HLA-C-Example",
      "description" : "Example of HLA-C",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-c"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DPA1-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DPA1-Example"
      },
      "name" : "HLA-DPA1-Example",
      "description" : "Example of HLA-DPA1",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-dpa1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DPB1-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DPB1-Example"
      },
      "name" : "HLA-DPB1-Example",
      "description" : "Example of HLA-DPB1",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-dpb1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DQA1-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DQA1-Example"
      },
      "name" : "HLA-DQA1-Example",
      "description" : "Example of HLA-DQA1",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-dqa1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DQB1-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DQB1-Example"
      },
      "name" : "HLA-DQB1-Example",
      "description" : "Example of HLA-DQB1",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-dqb1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DRB1-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DRB1-Example"
      },
      "name" : "HLA-DRB1-Example",
      "description" : "Example of HLA-DRB1",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-drb1"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DRB3-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DRB3-Example"
      },
      "name" : "HLA-DRB3-Example",
      "description" : "Example of HLA-DRB3",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-drb3"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DRB4-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DRB4-Example"
      },
      "name" : "HLA-DRB4-Example",
      "description" : "Example of HLA-DRB4",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-drb4"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-DRB5-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-DRB5-Example"
      },
      "name" : "HLA-DRB5-Example",
      "description" : "Example of HLA-DRB5",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-drb5"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-HLA-Multilocus-Genotype-Example.html"
      }],
      "reference" : {
        "reference" : "Observation/HLA-Multilocus-Genotype-Example"
      },
      "name" : "HLA-Multilocus-Genotype-Example",
      "description" : "Multilocus Genotype of HLA-A, HLA-B, HLA-DRB1, and HLA-DRB3",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/hla-genotype"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-a.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-a"
      },
      "name" : "HLA_A",
      "description" : "Genotype for HLA-A",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-b.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-b"
      },
      "name" : "HLA_B",
      "description" : "Genotype for HLA-B",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-c.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-c"
      },
      "name" : "HLA_C",
      "description" : "Genotype for HLA-C",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-dpa1.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-dpa1"
      },
      "name" : "HLA_DPA1",
      "description" : "Genotype for HLA-DPA1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-dpb1.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-dpb1"
      },
      "name" : "HLA_DPB1",
      "description" : "Genotype for HLA-DPB1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-dqa1.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-dqa1"
      },
      "name" : "HLA_DQA1",
      "description" : "Genotype for HLA-DQA1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-dqb1.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-dqb1"
      },
      "name" : "HLA_DQB1",
      "description" : "Genotype for HLA-DQB1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-drb1.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-drb1"
      },
      "name" : "HLA_DRB1",
      "description" : "Genotype for HLA-DRB1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-drb3.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-drb3"
      },
      "name" : "HLA_DRB3",
      "description" : "Genotype for HLA-DRB3",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-drb4.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-drb4"
      },
      "name" : "HLA_DRB4",
      "description" : "Genotype for HLA-DRB4",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-hla-drb5.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/hla-drb5"
      },
      "name" : "HLA_DRB5",
      "description" : "Genotype for HLA-DRB5",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-icd10-gvhd-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/icd10-gvhd-codes"
      },
      "name" : "ICD-10 (GVHD) Codes",
      "description" : "GVHD ICD-10 Codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-bundle.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-bundle"
      },
      "name" : "MatchSync Bundle",
      "description" : "Collection Bundle for MatchSync",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Bundle-BundleExample-Practitioner.html"
      }],
      "reference" : {
        "reference" : "Bundle/BundleExample-Practitioner"
      },
      "name" : "MatchSync Bundle Example - Practioners",
      "description" : "MatchSync Bundle Example with Patient, Search Coordinator, Referring Physician, and TC Physician",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/ms-bundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-bundle-hla-separate.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-bundle-hla-separate"
      },
      "name" : "MatchSync Bundle with Separate HLA",
      "description" : "Collection Bundle for MatchSync with separate HLA Observations for each locus",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-bundle-hla-multilocus.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-bundle-hla-multilocus"
      },
      "name" : "MatchSync Bundle with single multilocus HLA",
      "description" : "Collection Bundle for MatchSync with single HLA multilocus Observation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-MSDiagnosisExample-AML.html"
      }],
      "reference" : {
        "reference" : "Condition/MSDiagnosisExample-AML"
      },
      "name" : "MSDiagnosisExample-AML",
      "description" : "Example of a Diagnois: AML",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/msdiagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-MSDiagnosisExample-OND.html"
      }],
      "reference" : {
        "reference" : "Condition/MSDiagnosisExample-OND"
      },
      "name" : "MSDiagnosisExample-OND",
      "description" : "Example of a Diagnois",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/msdiagnosis"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-mspatient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mspatient"
      },
      "name" : "MSPatient",
      "description" : "Patient needing a transplant",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-MSPatientBirthSex.html"
      }],
      "reference" : {
        "reference" : "Patient/MSPatientBirthSex"
      },
      "name" : "MSPatientBirthSex",
      "description" : "Example of a patient using BirthSex codes",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-MSPatientExample.html"
      }],
      "reference" : {
        "reference" : "Patient/MSPatientExample"
      },
      "name" : "MSPatientExample",
      "description" : "Example of a patient needing a donor using us-core-race and us-core-ethnicity codes.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-MSPatientExample2.html"
      }],
      "reference" : {
        "reference" : "Patient/MSPatientExample2"
      },
      "name" : "MSPatientExample2",
      "description" : "Example of a patient needing a donor using NMDP race code.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-MSPatientExample3.html"
      }],
      "reference" : {
        "reference" : "Patient/MSPatientExample3"
      },
      "name" : "MSPatientExample3",
      "description" : "Example of a patient without a race code",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-MSPatientExample4.html"
      }],
      "reference" : {
        "reference" : "Patient/MSPatientExample4"
      },
      "name" : "MSPatientExample4",
      "description" : "Example of a patient needing a donor using us-core-race code but not us-core-ethnicity",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-MSPatientExample5.html"
      }],
      "reference" : {
        "reference" : "Patient/MSPatientExample5"
      },
      "name" : "MSPatientExample5",
      "description" : "Example of a patient needing a donor using NMDP race code.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/mspatient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-msdiagnosis.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/msdiagnosis"
      },
      "name" : "MSPrimaryDiagnosis",
      "description" : "Diagnosis",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-msspecimen.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/msspecimen"
      },
      "name" : "MSSpecimen",
      "description" : "Patient sample used for HLA typing",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Specimen-MSSpecimenExample.html"
      }],
      "reference" : {
        "reference" : "Specimen/MSSpecimenExample"
      },
      "name" : "MSSpecimenExample",
      "description" : "Example patient specimen.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/msspecimen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-nmdp-practitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/nmdp-practitioner"
      },
      "name" : "NMDPPractitioner",
      "description" : "NMDP Practitioner",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-nmdp-practitioner-role.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/nmdp-practitioner-role"
      },
      "name" : "NMDPPractitionerRole",
      "description" : "NMDP Practitioner Role",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-number-of-remissions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/number-of-remissions"
      },
      "name" : "Number of Remissions of Primary Diagnosis",
      "description" : "Number of Remissions of Primary Diagnosis",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-abogroup-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-abogroup-observation"
      },
      "name" : "Observation_MS_ABOGroup",
      "description" : "ABO Blood Group of Patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-aborhgroup-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-aborhgroup-observation"
      },
      "name" : "Observation_MS_ABORH",
      "description" : "ABO and Rh group [Type] in Blood",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-cmvgroup-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-cmvgroup-observation"
      },
      "name" : "Observation_MS_CMV",
      "description" : "Cytomeglovirus found in patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-form117-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-form117-observation"
      },
      "name" : "Observation_MS_Form117Compliance",
      "description" : "Form 117 Compliance for patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-height-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-height-observation"
      },
      "name" : "Observation_MS_PatientHeight",
      "description" : "Height of Patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-weight-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-weight-observation"
      },
      "name" : "Observation_MS_PatientWeight",
      "description" : "Weight of Patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-preferred-product-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-preferred-product-observation"
      },
      "name" : "Observation_MS_PreferredProduct",
      "description" : "Preferred product for transplant",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-rhstatus-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-rhstatus-observation"
      },
      "name" : "Observation_MS_RhStatus",
      "description" : "Rh status of Patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ms-transplant-timeline-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ms-transplant-timeline-observation"
      },
      "name" : "Observation_MS_TransplantTimeline",
      "description" : "Transplant timeline for patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-PhysicianExample.html"
      }],
      "reference" : {
        "reference" : "Practitioner/PhysicianExample"
      },
      "name" : "PhysicianExample",
      "description" : "Example of a practitioner.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-ReferringPhysicianRoleExample.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/ReferringPhysicianRoleExample"
      },
      "name" : "ReferringPhysicianRoleExample",
      "description" : "Example of Referring Physician Role",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-ietf-language-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/ietf-language-cs"
      },
      "name" : "Tags for the Identification of Languages",
      "description" : "Code System for IETF languages",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-TCCoordinatorExample.html"
      }],
      "reference" : {
        "reference" : "Practitioner/TCCoordinatorExample"
      },
      "name" : "TCCoordinatorExample",
      "description" : "Example of a practitioner.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-TCCoordinatorRoleExample.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/TCCoordinatorRoleExample"
      },
      "name" : "TCCoordinatorRoleExample",
      "description" : "Example of Transplant Center Coordinotor Role",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-TCExample.html"
      }],
      "reference" : {
        "reference" : "Organization/TCExample"
      },
      "name" : "TCExample",
      "description" : "Example of a Transplant Center.",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/transplantcenter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-TCPhysicianRoleExample.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/TCPhysicianRoleExample"
      },
      "name" : "TCPhysicianRoleExample",
      "description" : "Example of Transplant Center Physician Role",
      "exampleCanonical" : "http://fhir.nmdp.org/ig/matchsync/StructureDefinition/nmdp-practitioner-role"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-transplantcenter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/transplantcenter"
      },
      "name" : "TransplantCenter",
      "description" : "Transplant Center",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-loinc-abo-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/loinc-abo-codes"
      },
      "name" : "ValueSet - Blood Group (ABO) - LOINC",
      "description" : "LOINC codes for ABO blood group",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-abo-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-abo-codes"
      },
      "name" : "ValueSet - Blood Group (ABO) - NMDP",
      "description" : "NMDP blood group codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-loinc-abo-rh-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/loinc-abo-rh-codes"
      },
      "name" : "ValueSet - Blood Group (ABO+RH) - LOINC",
      "description" : "LOINC codes for ABO RH blood group",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-abo-rh-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-abo-rh-codes"
      },
      "name" : "ValueSet - Blood Group (ABO+RH) - NMDP",
      "description" : "NMDP blood group codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-loinc-posneg-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/loinc-posneg-codes"
      },
      "name" : "ValueSet - Blood Group (Rh) - LOINC",
      "description" : "LOINC codes for Positive and Negative",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-rh-status-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-rh-status-codes"
      },
      "name" : "ValueSet - Blood Group (Rh) - NMDP",
      "description" : "NMDP codes for Rh staus",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-loinc-cmv-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/loinc-cmv-codes"
      },
      "name" : "ValueSet - CMV Group - LOINC",
      "description" : "LOINC codes for CMV",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-cmv-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-cmv-codes"
      },
      "name" : "ValueSet - CMV Group - NMDP",
      "description" : "NMDP cmv codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-disease-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-disease-codes"
      },
      "name" : "ValueSet - Disease - NMDP",
      "description" : "NMDP disease codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-diseasestage-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-diseasestage-codes"
      },
      "name" : "ValueSet - Disease Stage - NMDP",
      "description" : "NMDP disease stage codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-ms-form117-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/ms-form117-codes"
      },
      "name" : "ValueSet - Form117 Compliance - NMDP",
      "description" : "NMDP Form 117 codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-language-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-language-codes"
      },
      "name" : "ValueSet - Language - NMDP",
      "description" : "NMDP language codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-ethnicity-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-ethnicity-codes"
      },
      "name" : "ValueSet - Patient Ethnicity - NMDP",
      "description" : "NMDP ethnicity codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-GenderIdentity-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-GenderIdentity-codes"
      },
      "name" : "ValueSet - Patient Gender Identity - NMDP",
      "description" : "NMDP GenderIdentity codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-race-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-race-codes"
      },
      "name" : "ValueSet - Patient Race - NMDP",
      "description" : "NMDP race codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-practitioner-role-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-practitioner-role-vs"
      },
      "name" : "ValueSet - PractitionerRole - NMDP",
      "description" : "NMDP Practitioner Role Value Set",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-preferred-product-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-preferred-product-codes"
      },
      "name" : "ValueSet - Preferred Product - NMDP",
      "description" : "NMDP preferred product codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-nmdp-transplant-timeline-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/nmdp-transplant-timeline-codes"
      },
      "name" : "ValueSet - Transplant Timeline - NMDP",
      "description" : "NMDP transplant timeline codes",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "Appendices.html"
        }],
        "nameUrl" : "Appendices.html",
        "title" : "Appendices",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "Downloads.html"
        }],
        "nameUrl" : "Downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "extra.html"
        }],
        "nameUrl" : "extra.html",
        "title" : "Extra",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
